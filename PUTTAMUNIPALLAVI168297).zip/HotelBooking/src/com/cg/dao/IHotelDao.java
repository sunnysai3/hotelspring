package com.cg.dao;

import java.util.List;

import com.cg.bean.Hotels;
import com.cg.bean.customer;



public interface IHotelDao {
	public List<Hotels> getAllHotels();
	public Hotels bookHotel(customer cust);
}
