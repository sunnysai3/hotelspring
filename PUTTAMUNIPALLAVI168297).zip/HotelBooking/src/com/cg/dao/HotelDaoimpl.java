package com.cg.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import com.cg.bean.Hotels;
import com.cg.bean.customer;



@Repository
public class HotelDaoimpl implements IHotelDao {


	
	
	@PersistenceContext
	private EntityManager entitymanager;

	@Override
	public List<Hotels> getAllHotels() {
		// TODO Auto-generated method stub
		String query="select hotel from Hotels hotel";
		TypedQuery<Hotels> tp=entitymanager.createQuery(query,Hotels.class);
		List<Hotels> lis=tp.getResultList();
		return lis;
	}

	@Override
	public Hotels bookHotel(customer cust) {
		// TODO Auto-generated method stub
		Hotels h = entitymanager.find(Hotels.class, cust.getHotelId());
		int arooms=h.getAvailableRooms();
		arooms=arooms-1;
		h.setAvailableRooms(arooms);
		entitymanager.merge(h);
		entitymanager.persist(cust);
		entitymanager.flush();
		return h;
	}
	

}
