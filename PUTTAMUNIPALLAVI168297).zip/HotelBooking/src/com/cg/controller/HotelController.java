package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.bean.Hotels;
import com.cg.bean.customer;
import com.cg.service.IHotelService;



@Controller
public class HotelController {
	@Autowired
	IHotelService hservice;
	
	@RequestMapping("/details")
	public String viewHotels(Model m) {
		List<Hotels> lis = hservice.allHotels();
		m.addAttribute("hlist", lis);
		return "HotelDetails";
		
	}
	
	@RequestMapping("/book")
	public ModelAndView veiwBookingpage(int id){
		customer cust=new customer();
		ModelAndView m=new ModelAndView("bookingPage");
		m.addObject("hotelid", id);
		m.addObject("customer", cust);
		return m;
	}
	
	
	
	@RequestMapping(value="/booking",method=RequestMethod.POST)
	public ModelAndView bookHotels(@ModelAttribute("customer") @Valid customer cust,String from,String to,int hotelid,Model mo) {

		cust.setToDate(to);
		cust.setFromDate(from);
		cust.setHotelId(hotelid);
		Hotels hr = hservice.bookHotel(cust);
		ModelAndView m=new ModelAndView("hotelBookingSuccess","hname",hr.getName());
		return m;
	}
	
	
	@RequestMapping(value="/home" )
	public String goHome() {
		return "index";
	}
	
	
	
		
	
	
}

  