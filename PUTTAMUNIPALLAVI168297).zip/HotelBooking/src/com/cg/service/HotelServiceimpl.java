package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;
import javax.xml.bind.annotation.XmlTransient;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Hotels;
import com.cg.bean.customer;
import com.cg.dao.IHotelDao;

@Service
@Transactional
public class HotelServiceimpl implements IHotelService {
	@Autowired
	IHotelDao dao;

	@Override
	public List<Hotels> allHotels() {
		// TODO Auto-generated method stub
		return dao.getAllHotels();
		
	}

	@Override
	public Hotels bookHotel(customer cust) {
		// TODO Auto-generated method stub
		return dao.bookHotel(cust);
	}

	

}
